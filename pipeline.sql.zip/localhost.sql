-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Vært: localhost
-- Genereringstid: 03. 06 2012 kl. 11:06:50
-- Serverversion: 5.5.9
-- PHP-version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pipelinetool`
--
DROP DATABASE `pipelinetool`;
CREATE DATABASE `pipelinetool` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pipelinetool`;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kunder`
--

DROP TABLE IF EXISTS `kunder`;
CREATE TABLE IF NOT EXISTS `kunder` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kundenavn` text,
  `kundenummer` int(11) DEFAULT NULL,
  `highriselink` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Data dump for tabellen `kunder`
--

INSERT INTO `kunder` VALUES(1, '3F', NULL, NULL);
INSERT INTO `kunder` VALUES(2, 'Storebælt', NULL, NULL);
INSERT INTO `kunder` VALUES(3, 'Lederne', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `tender`
--

DROP TABLE IF EXISTS `tender`;
CREATE TABLE IF NOT EXISTS `tender` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kundeid` int(11) DEFAULT NULL,
  `projekt` text,
  `status` text NOT NULL,
  `kd` varchar(11) DEFAULT NULL,
  `pl` varchar(11) DEFAULT NULL,
  `tag` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Data dump for tabellen `tender`
--

INSERT INTO `tender` VALUES(3, 1, 'Cookie politik', 'aktiv', 'cp', 'lv', '');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `tenderrevision`
--

DROP TABLE IF EXISTS `tenderrevision`;
CREATE TABLE IF NOT EXISTS `tenderrevision` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tenderid` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `sandsynlighed` int(11) DEFAULT NULL,
  `andel1` int(11) DEFAULT NULL,
  `andel2` int(11) DEFAULT NULL,
  `andel3` int(11) DEFAULT NULL,
  `andel4` int(11) DEFAULT NULL,
  `andel5` int(11) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `slut` date DEFAULT NULL,
  `opdateret` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data dump for tabellen `tenderrevision`
--

